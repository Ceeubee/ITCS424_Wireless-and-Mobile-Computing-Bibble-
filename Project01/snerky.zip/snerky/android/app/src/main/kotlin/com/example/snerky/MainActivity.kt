package com.example.snerky

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
